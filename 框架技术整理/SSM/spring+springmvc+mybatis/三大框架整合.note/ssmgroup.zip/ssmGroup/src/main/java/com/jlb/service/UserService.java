package com.jlb.service;

import com.jlb.domain.User;

public interface UserService {

	// 判断用户登录信息是否正确
	User login(User user);
}
