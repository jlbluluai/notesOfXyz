package com.jlb.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.jlb.domain.Book;

public interface BookMapper {

	// 查询所有图书
	@Select("select * from tb_book")
	List<Book> selectAllBook();
}
