package com.jlb.dao;

import org.apache.ibatis.annotations.Select;

import com.jlb.domain.User;

public interface UserMapper {

	// 根据登录名和密码查询用户
	@Select("select * from tb_user where loginname=#{loginname} and password=#{password}")
	User selectUserByLogin(User user);
}
