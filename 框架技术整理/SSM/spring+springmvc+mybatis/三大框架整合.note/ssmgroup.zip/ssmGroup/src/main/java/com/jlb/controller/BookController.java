package com.jlb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jlb.domain.Book;
import com.jlb.service.BookService;

@Controller
public class BookController {

	@Autowired
	@Qualifier("bookService")
	private BookService bookService;

	@RequestMapping(value = "/main")
	public String main(Model model) {
		List<Book> blist = bookService.getAllBook();
		model.addAttribute("blist", blist);
		return "main";
	}

}
