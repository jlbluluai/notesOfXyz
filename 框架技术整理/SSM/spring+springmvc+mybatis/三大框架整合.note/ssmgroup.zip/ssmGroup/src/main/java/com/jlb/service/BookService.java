package com.jlb.service;

import java.util.List;

import com.jlb.domain.Book;

public interface BookService {

	// 查找所有图书
	List<Book> getAllBook();
}
