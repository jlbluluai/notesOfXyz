package com.jlb.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jlb.dao.BookMapper;
import com.jlb.domain.Book;
import com.jlb.service.BookService;

@Service("bookService")
public class BookServiceImpl implements BookService {

	@Autowired
	private BookMapper bookMapper;

	@Override
	public List<Book> getAllBook() {
		return bookMapper.selectAllBook();
	}

}
