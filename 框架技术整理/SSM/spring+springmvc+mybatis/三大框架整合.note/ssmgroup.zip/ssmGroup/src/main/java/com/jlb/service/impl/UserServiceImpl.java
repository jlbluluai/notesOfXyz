package com.jlb.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jlb.dao.UserMapper;
import com.jlb.domain.User;
import com.jlb.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userMapper;

	@Override
	public User login(User user) {
		return userMapper.selectUserByLogin(user);
	}

}
