package com.jlb.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jlb.entity.Book;

@Controller
public class BookController {

	@RequestMapping(value = "/main")
	public String main(Model model) {
		// 模拟数据库获得所有图书集合
		List<Book> book_list = new ArrayList<Book>();
		book_list.add(new Book("1.jpg", "天龙八掌", "杨骚", 58.5));
		book_list.add(new Book("1.jpg", "玄真七经", "杨骚", 58.5));
		book_list.add(new Book("1.jpg", "弹指神功", "杨骚", 58.5));
		book_list.add(new Book("1.jpg", "滑稽大法", "杨骚", 58.5));
		model.addAttribute("book_list", book_list);
		return "main";

	}
}
