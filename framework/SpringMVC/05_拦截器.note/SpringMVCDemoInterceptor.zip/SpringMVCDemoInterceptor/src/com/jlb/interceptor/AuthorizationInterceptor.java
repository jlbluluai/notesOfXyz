package com.jlb.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.jlb.entity.User;

public class AuthorizationInterceptor implements HandlerInterceptor {

	//不拦截loginForm login
	private static final String[] IGNORE_URI={"/loginForm","/login"};
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception)
			throws Exception {

		System.out.println("afterCompletion 执行了...");
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView mv)
			throws Exception {

		System.out.println("postHandle 执行了...");
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		System.out.println("preHandle 执行了...");
		//flag用来判断用户是否拦截路径
		boolean flag=false;
		//获取请求路径进行判断
		String servletPath =request.getServletPath();
		System.out.println(servletPath);
		//判断请求是否需要拦截
		for(String s:IGNORE_URI){
			if(servletPath.contains(s)){
				flag=true;
				break;
			}
		}
		//拦截
		if(!flag){
			//获得session中的用户
			User user=(User)request.getSession().getAttribute("user");
			//判断用户是否已经登录
			if(user==null){
				System.out.println("拦截开始...");
				request.setAttribute("message", "请先登录再访问网站");
				request.getRequestDispatcher("loginForm").forward(request, response);
			}else{
				System.out.println("放行...");
				flag=true;
			}
		}
		System.out.println(flag);
		return flag;
	}

}
