package com.jlb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FormController {

	@RequestMapping(value = "/{formname}")
	public String loginForm(@PathVariable String formname, Model model) {
		System.out.println("loginFrom方法执行了...");
		return formname;
	}
}
